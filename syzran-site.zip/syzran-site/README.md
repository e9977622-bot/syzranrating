# Сызрань: битва за рейтинг. Как выложить в интернет

В папке готовый сайт:
- `index.html` — сама игра (общий рейтинг через Firebase от Google)
- `firestore.rules` — правила базы данных
- `firebase.json` — настройки хостинга
- `robots.txt`, `sitemap.xml` — для поиска Google

Без шага 3 игра тоже запустится, но рейтинг будет только на устройстве каждого игрока.

## 1. Создай проект Firebase (бесплатно)
1. Открой [Firebase Console](https://console.firebase.google.com/) и войди в аккаунт Google.
2. Нажми «Создать проект», введи название (например, `syzran-rating`). Google Analytics можно отключить.

## 2. Включи вход и базу данных
1. **Authentication** → «Начать» → вкладка «Способ входа» → включи **Анонимный**.
2. **Firestore Database** → «Создать базу данных» → выбери регион (например, `europe-west`) → режим «рабочий».
3. Вкладка **Правила** → удали всё и вставь содержимое файла `firestore.rules` → «Опубликовать».

## 3. Вставь настройки в сайт
1. Шестерёнка → «Настройки проекта» → внизу «Ваши приложения» → значок веб-приложения `</>`.
2. Зарегистрируй приложение, скопируй значения `apiKey`, `authDomain`, `projectId`, `appId`.
3. Открой `index.html`, найди блок `window.FIREBASE_CONFIG` и замени значения.

## 4. Выложи сайт
Самый простой способ — Firebase Hosting ([инструкция Google](https://firebase.google.com/docs/hosting/quickstart)). Сначала установи [Node.js](https://nodejs.org/), потом в терминале:
```
npm install -g firebase-tools
firebase login
firebase use --add      # выбери свой проект
firebase deploy
```
В конце появится адрес вида `https://syzran-rating.web.app`.

Если выкладываешь на свой домен или другой хостинг (Netlify, GitHub Pages), добавь домен в Authentication → Параметры → «Авторизованные домены».

## 5. Чтобы нашёл Google
1. В `index.html`, `robots.txt` и `sitemap.xml` замени `ВАШ-САЙТ.web.app` на свой адрес.
2. Выложи сайт заново (`firebase deploy`).
3. Открой [Google Search Console](https://search.google.com/search-console) → «Добавить ресурс» → подтверди владение сайтом.
4. В разделе Sitemaps добавь `sitemap.xml`, а в «Проверке URL» запроси индексацию главной страницы.

Google может проиндексировать сайт через несколько дней или недель. Мгновенно в поиске он не появится.

## Полезные ссылки
- [Firebase Console](https://console.firebase.google.com/) — проект, база данных, вход
- [Анонимный вход: документация](https://firebase.google.com/docs/auth/web/anonymous-auth)
- [Firebase Hosting: быстрый старт](https://firebase.google.com/docs/hosting/quickstart)
- [Node.js](https://nodejs.org/) — нужен для команды `firebase`
- [Google Search Console](https://search.google.com/search-console) — чтобы сайт попал в поиск
- [Тарифы и лимиты Firebase](https://firebase.google.com/pricing)

## Что нужно знать
- **Лимиты бесплатного тарифа Spark:** 50 000 чтений и 20 000 записей Firestore в сутки. Если играть будет много людей, лимит закончится, и рейтинг перестанет обновляться. Тогда нужен тариф Blaze (включи уведомления о расходах).
- **Читерство:** игра работает в браузере, поэтому технически подкрутить свой счёт можно. Правила базы ограничивают только формат данных, а не величину очков.
- **Боты** считаются по времени прямо в браузере и у всех одинаковые, в базе они не хранятся.
